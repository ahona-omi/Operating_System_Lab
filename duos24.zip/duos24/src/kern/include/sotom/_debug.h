#ifndef __LIBS_DEBUG_LINKER_H__
#define __LIBS_DEBUG_LINKER_H__
#include <stdint.h>


#endif
